package kr.green.batch.vo;

import org.joda.time.LocalDate;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class ExamResultFieldSetMapper implements FieldSetMapper<ExamResult>{
//txt내용을 읽어서 ExamResultFiedSetMapper로 가져가고 
//밑의 lineTokenizer로 들어간 다음/로 잘라서 다시 DefaultLineMapper로 들어가고 
//다시 ExamResultFieldSetMapper로 들어간다

	@Override // FieldSet으로 넘어온 값을 VO로 만들어 리턴해주는 맵퍼 클래스
	public ExamResult mapFieldSet(FieldSet fieldSet) throws BindException {
		ExamResult examResult = new ExamResult();
		examResult.setStudentName(fieldSet.readString(0));//0번째 필드를 이름으로 저장
		examResult.setDob(new LocalDate(fieldSet.readDate(1,"dd/MM/yyyy")));//1번째 필드를 일/월/년으로 저장
		examResult.setPercentage(fieldSet.readDouble(2));//2번째 필드를 Double형으로 저장
		return examResult;
	}

}

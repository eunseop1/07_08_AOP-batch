package kr.human.aop.app;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import kr.human.aop.service.EmployeeService;
import kr.human.aop.vo.EmployeeVO;

public class AppMain3 {
	public static void main(String[] args) {
		AbstractApplicationContext context =
				new ClassPathXmlApplicationContext("bean3.xml");
		
		EmployeeService employeeService = context.getBean("employeeService", EmployeeService.class);
	
		EmployeeVO employeeVO = employeeService.selectById(1);//리턴값 있다
		System.out.println(employeeVO);
		System.out.println("-".repeat(80));
		
		List<EmployeeVO> list = employeeService.selectList();//리턴 값이 있다
		System.out.println(list);
		System.out.println("-".repeat(80));
		
		employeeService.insertEmployee(null);//리턴값이 없다 -> afterReturningLog()의 로그에 리턴 값이 null로 나온다
		
		context.close();
	}
}

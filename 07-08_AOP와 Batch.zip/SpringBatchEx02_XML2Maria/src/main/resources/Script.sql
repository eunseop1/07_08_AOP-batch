create table EXAM_RESULT(
	idx int primary key auto_increment,
	student_name varchar(20) not null,
	DOB date not null,
	Percentage float(7, 2) not null
);

drop table exam_result;

select * from exam_result;